#include "player.h"
player:: player(){
	runs scored=0;
	balls played=0;
	balls bowled=0;
	runsgiven=0;
	wiketstaken=0;

}


