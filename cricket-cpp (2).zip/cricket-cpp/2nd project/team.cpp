#include"team.h"
team::team(){
	total runs scored=0;
	wicketslost=0;
	totalballsbowled=0;


}

#include"player.h"
#include<vector>
class team{
public:
	team();

	std:: string teamname;

	int totalruns scored;
	int wicketslost;
	int total ballsbowled;
	std:: vector<player> players;

};
