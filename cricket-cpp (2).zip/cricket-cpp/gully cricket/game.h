#include"team.h"
#include<ctime>
#include<cstdlib>
#include<iostream>


class game{

public:
	game();
	team teamA, teamb;
	team *batting team;

	team *bowling team;

	player * batsman;

	player * bowler;

	bool is first innings;

	int.players team;

	int maxballs;

	int total player;

	std:: string player[11];

	void welcome();

	void displaypoolplayers();

	int takenintegersonly();

	void create teams();
	bool validating players(int);

	void show teams();

	void toss();

	void toss choices(team);
	void start first innings();
	void initializing players();

	void playinnings();

	void show scorecard();

	void bat();

	bool validateinnings();
	void startsecond innings();
	void showmatchsummary();

};


\\virtual crickets application.

# include"game.h"
using namespace std;
int main(){
	 game game;
	 game.welcome();
	 cout <<"\n\n\t\t\t\t pree enter to see the pool of 11 players...........";
	 getchar();

	 game.displaypool players();
	 cout<<"\n\n\t\t\t\t pree enter to create the two teams...........";

	 getchar();

	 game.createteam();


	 cin.ignore(numric-limits<streamsize)::max(),'\n';



	 cout<<"\n\n\t\t\t\tpress enter to see the created teams..........\n";


	 getchar();


	 game.showteams();


	 cout<<'\n\n\t\t\t\t press enter to toss ...........\n";


			 getchar();
	 cin.ingore(numric_limits<streamsize>::max(),'\n');


	 game.toss();

	 cout<<"\n\n\t\t\t\t press enter to start first innings.........\n";

	 getchar();


	 game.start firstinnings();

	 cin.ignore(numric_limits<stream size>::max(),'\n');

	 cout<<"\n\n\t\t\t\t press enter to start second innings...........\n";

	 getchar();

	 game.startsecondinnings();

	 cout<<"\n\n\t\t\t press enter to see match summary ...........\n";

	 getchar();

	 game.showmatch summary();
	 return 0;
}
