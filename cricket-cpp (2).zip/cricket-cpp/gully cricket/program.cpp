/*
 * program.cpp
 *
 *  Created on: Feb 20, 2021
 *      Author: Aishwariya
 */


#include"Game.h"
#include<limits>
#include<ctime>
#include<cstdlib>

using namespace std;
Game:: GAME(){

	teamA. teamname="team-A";
	 teamB. teamname="team-B";
	 is firstname=false;
	 players team=3;
	 maxballs=6;
	 total players=11;


player[0]="virat";
player[1]="rohit";
player[2]="dhoni";
player[3]="pant";
player[4]="kl rahul";
player[5]="raina";
player[6]="jadeja";
player[7]="sachin";
player[8]="kartin";
player[9]="b kumar";
player[10]="bumbrah";

}


Void Game::Welcome(){

	cout<<"/t/t/t________________________________________________________/n";
	cout<<"/t/t/t|                                                    |\n";
    cout<<"\t\t\t|==========================CRIC_IN========================|\N";
    cout<<"\t\t\t|---------------------------------------------------------|\n";
    cout<<"\t\t\t|___________________________to______________________________|n";
    cout<<"\t\t\t=======================virtual-cricket-game=================|/n";
    cout<<"\t\t\t                                                            |/n/n";
    cout<<"\t\t\t____________________________________________________________|\n";
    cout<<"\t\t\t|==========================rule=============================|/n";
    cout<<"\t\t\t------------------------------------------------------------|/n";
    cout<<"\t\t\t|                                                           |/n";





    cout<<"\t\t\t|1. you have to form two team select 3 players for each team from the given pool of 11 players.|\n";

     cout<<"\t\t\t|2.win the toss and select what you will do batting or bowling|/n";


     cout<<"\t\t\t|3. there will be 6 balls in each inning.|\n";

     cout<<"\t\t\t|                                                          |\n\n";


}


VOID GAME:: displaypoolplayers(){
	int i;

	cout<<"\t\t\t                                                             /n";
	cout<<"\t\t\t|                                                          |\n";
	cout<<"\t\t\t|==========================pool-of-11-players===============|/n";
	cout<<"\t\t\t|                                                         |\n\n\n";


	for(i=0; i<total player;i++)
	{
		cout<<"\t\t\t\t\t\t\["<<i<<"] "<< player[i]<<"\n";
	}
}


int Game:: takeintegeronly(){


	int i;
	 while (!(cin>>i)){

		 cin. clear();
		 cin.ignore( numrin-limits<<stream size>::max(),  '\n');
		 cout<<"\t\t\t\t\t\t\t\.ERROR!!! please try again with valid input:";

	}
	  return !;
}
bool GAME::validating players(intp){

	int i;
	vector<player> players= teamA.players;
	int n=players.size();

	for(i=0; i<n; i++){

		if(players[i].id==p){
			return false;

		}
	}



	players=team B.players;

	n=players.size();

	for(i=0; i<n; i++){

		if(players[i].id==p){

			return false;

		}
	}
	return true;
}

voidgame:: create team(){


	int i;

	cout<<"\t\t\t|_______________________________________________________________________________/n";

	cout<<"\t\t\t|______________________________________________________________________________|/n";
	cout<<"\t\t\t|=======================create team-A and team-B=========================|/n";

cout<<"\t\t\t|___________________________________________________________|\n\n";

for(i=0; i<playersperteam; i++){
	cout<<"/n";

	team selection:

	cout<<"\t\t\t\t\t\tENTER the player"<<i+<<"of team -A:";
	int player team A=takeintegeronly();
	if(player team A<0||playerA>10){
		cout<<"\t\t\t\t\t\t\tERROR!!!player is already taken please select any other playe /n";
		goto team selection;
	}
	else{
		player teamA player;
		teamAplayer.id=playerteamA;
		teamAplayer.name=player[player teamA];
		teamA.players.push_back(teamA player);
	}


	teamB selection:

	cout<<"\t\t\t\t\t\t\tenter the player"<<i+1<<"of team-B:";

	int player teamB<<011 player teamB>10){


		cout<<"\t\t\t\t\t\t\t error!!! please enter valid input from given indices\n";

		goto teamselection;
	}

	else{
		player team B player;
		teamB player .id=player teamB;
		teamB player.name=player[player teamB];
		teamB.player.push-back(teamBplayer);
	}
}
}



void GAME::show team(){
	vector<player> player=teamA.players;
	vector<player>players=teamB.players;

	int i;


	cout<<"\t\t\t|__________________________________\t\_________________________________\n";

	cout<<"\t\t\t|_________________________________|\t\|_________________________________|\n";
	cout<<"\t\t\t|====================team-A=======|\t\t\t\==========team-B==============|\n";
	cout<<"\t\t\t|____________________________________|\t\t|________________________________|\n\n";

	for(i=0; i<playersperteam;i++){

		cout<<"\t\t\t\t\t["<<players[i].id<<"]."<<players[i].name<<"\t\t\t\t\t\t["<<player[i].id<<"]."<<player[i].name<<"\n";
	}
}




void game::toss(){

	int randomvalue;

	cout<<"\t\t\t|_____________________________________________________________________________\n";
	cout<<"\t\t\t|______________________________________________________________________________|\n";
	cout<<"\t\t\t|========================================toss=====================|\n";
	cout<<"\t\t\t|_________________________________________________________________|\n";


	srand(time(null));

	random value=rand()%2;
	switch(random value){


	case0;

	cout<<"\n\t\t\t\t team-A won the toss\n";
	toss choices(teamA);
	break;

	case1:
	cout<<"\n\t\t\t\t\t team-B won the toss\n";
	 toss choices(team B);
	 break;
	}
}
int choice;
cout<<"\n\t\t\t||||choose|||\n";

cout<<"|\t\t\t\t1.batting\n";
cout<<"\t\t2.bowling\n";
cout<<"\t\t\tenter the choice(1 for batting and 2 for bowling):";
choice=takeintegeronly();
switch(choice){

case1:
cout<<"|n\t\t\tteam-Bwon the toss\n";
tosschoice(teamB);
break;
}
}
void game::toss choices(team toss winner team){ \* deciding to bat or ball for the winning team and initializing battingv team and bowling team*|



	int choice;
cout<<"\n\\t\t||| choose|||\n";
cout<<"\t\t\t 1. batting\n";

cout<<"\t\t\t\t2.bowling\n";
cout<<"\\t\t\t enter the choice (1 for batting and 2 for bowling):";


choice=take integer only ();
switch (choice){

case1:
cout<<"\n\t\t\t"<<toss winnert team team name <<"won t5he toss and decided to bat first/n";

if (toss winner team. teamname.compare("team-A")==0){

	battingteam=&teamB;
	bowlingteam=&teamA;
}

break;
case2:
cout<<"\n\t\t\t"<<toss winner team.teamname<<"won the toss and decided to ball first\n";

if(toss winner team.teamname.campare("team-A")==0){
	bowling team=&teamA;
	battying team=&teamB;
}

break;

default:
	cout<<"\n\t\t\terror!!! please enter the valuid choice:";
	tosschoices(toss winner team):
		break;
}
}
void game::startfirstinnings(){

	cout<<"\t\t\t____________________________________________________________________________\n";
	cout<<"\t\t\t\t|                                                                          |/n;"
	cout<<"\t\t\t|===================first-innings-starts====================|/n";
	cout<<"|\t\t\t                                                                              |\n";
	is firstinnings=true;
	innitializing players();
	playinnings();
}
voidgame::start second innings(){
	cout<<"\t\t\t\t______________________________________________________________\n";
	cout<<"\t\t\t\t|______________________________________________________________|\n";
	cout<<"\t\t\t\t=============================second-innings-sarts=============|\n";
	cout<<"\t\t\t\t|______________________________________________________________|\n";

	is firstinnings=false;

	team teamteam=*batting team;
	*battingteam=*bowlingteam;
	*bowlingteam=temtemp;

	initializing players();
	playinning();
}

void GAME:: intializing players(){
	batsman=&batting->players[0];
	bowler=bowlingteam->players[0];

	cout<<"\n\t\t\t\t"<<batting
			team-> team name<<":"<<batsman->namer<<"is going to bat\n";
	cout<<"\n\t\t\t\t"<< bowling team-> teamname<<":"<<bowler->name<<"is going to ball \n";

}

void game:: playinning(){

	int i;
	for(i=0; i<maxballs;i++){

		cout<<"\n\t\t\t\tpress to ball...............\n";
		getchar();
		bat();
	}
}

void game::bat(){
	int runsscored;
	srand(time(null));
	runsscored=rand()%7;


	\\updating batting specs
	bowler->balls bowled=bowler-> ballsbowled+1;
	bowler->runsgiven=bowler->rungiven+runs scored;
	bowlingteam->totalballsbowled=bowlingteam->totalballsbowled+1;

	if(runsscored!=0){


		cout<<"\n\t\t\t\t"<<bowler->name<<"to"<<batsman->name<<"  "<<runsscored<<"runs scored!.\n";
	}

	else {

		cout<<"\n\t\t\t\t"<< bowler->name<<"to"<<battsman->name<<"! out ! \n";

		bowler->wicketstaken=bowler->wicketstaken+1;


		batting team->wicketslost=batting team->wickets lost+1;

		showscore card();

		int newindex=battingteam->wicketslost;

		batsman=&battingteam->players[newindex];
	}
}

void game::showscorecard(){
	cout<<"\n\t\t\t\t|====batting stats=============|";

	cout<<"\n\t\t\t\t______________________________________________________";

	cout<<"\n\t\t\t\t"<<batsman->name<<":"<<batsman-> runsscored<<"("<<batsman->ballsplayed<<")";

	cout<<"\n\t\t\t====================================================";

	cout<<"\n\t\t\t\t"<<batting team -> teamname<<":"<<battingteam->totalrunsscored<<"-"<<batting team->wicketslost;

	cout<<"\n\t\t\t                                                                      ";

	cout<<"\n\t\t\t\t|===================bowling starts===================|";

	cout<<"\n\t\t\t\t___________________________________________________________________________________";


	cout<<"\n\t\t\t"<<bowler->name<<":"<<bowler->runs given<<"("<<bowlewr->balls.bowled<<"j";

	cout<<"\n\t\t\t\t________________________________________________________________________";

	cout<<"\n\t\t\t\t"<<bowling team->team name<<":"<<batting team->total runsscored<<"("<<bowling team->total balls bowled<<")";

	cout<<"\n\t\t\t____________________________________________________________________________";
}


boolgame::validateinnings(){


	if(is first innings){
		if(batting team-> wicketlost==playersper team\\bowlingteam->total balls bowled==maxballs){

			cout<<"\t\t\t\t_____________________________________________________________\n";
           cout<<"\t\t\t\t|                                                             |\n";
           cout<<"\t\t\t\t|============================first-innings-ends===============|\n";
           cout<<"\t\t\t\t|_______________________________________________________________|\n";
           cout<<"\t\t\t\t|=========================<<batting team->team name<<"=================================\n";"




cout<<"\t\t\t\t\t\t\t"<< << batting team->total runsscored<<"_"<<batting team-> wicketslost<<"\n";


           cout<<"\n\t\t\t\t\t\t\t!!! result!!!";
           cout<<"\n\t\t\t\t"<<bowling team->team name <<"needs to score "<< batting team->total runs scored+1<<"runs";

           cout<<"\n"<<maxballs<<"balls\n";



           return false;
		}
	}

	else {
		if(batting team-> totalruns scored>bowling team->total runs scored){

			cout<<batting team->team name<<"won the match"<<\n\n";"

					return false;

		}


		else if (batting team ->wickets lost ==player perteam ||bowling team ->total balls bowled==max ballds)
	}

	if(batting team ->total runs scored <bowling team-> total runs. scored){

		cout<<bowling team -> team name<<"won the match"<"\n\n";
	}

	else {

		cout <<"match draw "<<"\n\n";

	}

	return false;

}

return true;

}


void game ::show match summary(){


	cout<<"\t\t\t\t|||match ends |||"<<"\n\n";


	cout <<batting team-> team name <<" "<<batting team -> total runs scored <<"_"<<batting team ->wickets lost<<"("<< bowling team -> total balls bowled<<")"<<"\n";

	cout<<"\t\t\t\t====================================================================="<<"\n;"

			cout<<"\t\t\t\t|player|\t batting\ t bowling \"<<"\n;


	for(int j=0; j<playersperteam; j++){

		player player= batting team ->players[j];

		cout<<"\t\t\t\t|_______________________________________________________|<<"\n";"
				cout<<"\t\t\t\t|"<<"["<<j<<"]"<<player.name<<"\t";

		cout<<player.runsscored<<"("<<player.ballsplayed<<")\t\t";
		cout<<player.ballsbowled<<"_"<<player.rungiven<<"_";

		cout<<player.wicketstaken<<"\t\"<<"\n";"}
	cout<<"\t\t\t\t|============================================"<<"\n\n";

	cout<<bowlingteam->teamname<<" "<<bowlingteam->total runsscored<<"_"<<bowlingteam->wicketslost<<"("<<battingteam->total balss bowled<<")"<<"\n";

	cout<<"\t\t\t\t========================================"<<"\n";

	cout<<"\t\t\t\t\t| player\t bating\t bowling\"<<"\n";"
			for(int i=0; i<playersteam; i++){

				player player=bowling team-> players pewrteam[i];

				cout<<"\t\t\t\t|                                                                                                    |"<<"\n";


				cout<<"\t\t\t\t|"<<"["<<i<<"]"<< player.name<<"\t";

				cout<<player.runsscored<<"("<<player.balls played<<")"\t\t";"
						cout<<player.ballsbowled<<"_"<<player.runsgiven<<"_";

				cout<<player.wicketstaken<<"\t\"<<"\n";"
						}
	cout<<"\t\t\t\t================================================================"<<"\n\n";
}









	}
}



}





