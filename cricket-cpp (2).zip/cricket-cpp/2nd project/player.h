#include<string>
class player{
public:
	player();
	std: string name;
	int id;
	int runs scored;
	int balls played;
	int runs given;
	int wickets taken;

};
